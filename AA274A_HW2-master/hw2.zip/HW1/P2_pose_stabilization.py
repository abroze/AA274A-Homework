import typing as T
import math
import numpy as np
from utils import wrapToPi

# command zero velocities once we are this close to the goal
RHO_THRES = 0.05
ALPHA_THRES = 0.1
DELTA_THRES = 0.1

class PoseController:
    """ Pose stabilization controller """
    def __init__(self, k1: float, k2: float, k3: float,
                 V_max: float = 0.5, om_max: float = 1) -> None:
        self.k1 = k1
        self.k2 = k2
        self.k3 = k3

        self.V_max = V_max
        self.om_max = om_max

    def load_goal(self, x_g: float, y_g: float, th_g: float) -> None:
        """ Loads in a new goal position """
        self.x_g = x_g
        self.y_g = y_g
        self.th_g = th_g

    def compute_control(self, x: float, y: float, th: float, t: float) -> T.Tuple[float, float]:
        """
        Inputs:
            x,y,th: Current state
            t: Current time (you shouldn't need to use this)
        Outputs:
            V, om: Control actions

        Hints: You'll need to use the wrapToPi function. The np.sinc function
        may also be useful, look up its documentation
        """
        ########## Code starts here ##########

        self.x = x
        self.y = y
        self.th = th

        self.rho = np.sqrt((self.x_g - self.x)**2 + (self.y_g - self.y)**2)
        self.alpha = wrapToPi(np.arctan2((self.y_g - self.y), (self.x_g - self.x)) - self.th)
        self.delta = wrapToPi(np.arctan2((self.y_g - self.y), (self.x_g - self.x)) - self.th_g)

        V = self.k1 * self.rho * math.cos(self.alpha)
        om = self.k2 * self.alpha + self.k1*(np.sinc(self.alpha/np.pi)*np.cos(self.alpha))*(self.alpha+self.k3*self.delta)

        ########## Code ends here ##########

        # apply control limits
        V = np.clip(V, -self.V_max, self.V_max)
        om = np.clip(om, -self.om_max, self.om_max)

        return V, om
